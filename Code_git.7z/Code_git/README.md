---
output:
  html_document: default
  word_document: default
  pdf_document: default
---
% README
 

## Content

 This repository contains various files that need to be downloaded and place together in  a folder named 'Code'.
 The file are:

+ 1 yml file **_environment_microalgae.yml_** used to reproduce the conda environment on your machine.  


+ 1 text file **_text_environment_microalgae.txt_** which can also be used to reproduce the conda environment on your machine.  


+ 206 csv files containing temperature and irradiance data (W.m-2) evolution over an average day of each month of the cultivation period in the 3 locations modeled in the simulations.   
As an example,
*dailydataforlat=57.109andlong=10.193formonth8forangle90forazimuth-90.csv_*
gives the irradiance (W) received by 1 m2 of surface tilted with an angle 90° (vertical) and facing azimuth  90°, for a location with coordinates 57.109,10.193 
Using the model with another location than the ones in these csvs and in the scripts would make the script download the new csvs automatically.  


+ 1 csv file **_elemental_contents.csv_** which contains  average elemental compositions (N, P, C) of microalgal macromolecules (Lipid, Phospholipids, proteins, Carbohydrates) as given 
by Geider et al. 2011.  


+ 1 csv file **_Feed_composition_** containing the fish feed composition in terms of ingredients (wheat, oil etc.) and the calculated composition in term of macromolecules (Lipid, proteins, carbohydrates, ash, water).  

+ 1 R script named **_Plot_** which is used to plot the figures from the  article based on the results of the simulations.  


+ 12 Python scripts for the simulations.  

+ Additionally, the Brightway project file **_brightway2-project-Microalgae_1-backup.01-December-2021-12-35AM.tar.gz  _** containing the foreground database needs to be downloaded from : https://drive.google.com/file/d/13Kc2yAyb3EGOtjNCjaH0dgh5DwDUbLBN/view?usp=sharing

The csv, the scripts and their functions'interconnections are mapped in the pdf file named "Scripts map" and below.  
<br>  


<img src="Code map.png"
     alt="Markdown Monster icon"
     style="float: left; margin-right: 10px;" />  
     <br>  
     
*Scripts with a 1 in their names contains functions needed for the simulations to generate the figures from the paper.*
<br>

**Retrieving_solar_and_climatic_data_1** 

Contains functions which download solar and temperature data from the European Photovoltaic Geographical System and estimate the solar power received by a given PBR geometry during the day.


**Functions_for_physical_and_biological_calculations_1**

Contains functions to calculate values related to :

+ Strain biology and metabolism
+ PBR geometry
+ Culture physical properties and centrifugation
+ Optimization for fish feed substitution


**Cultivation_simul_Night_Harvest_1**

Contains functions which simulate the cultivation over a day with solving of differential equations for temperature evolution and associated thermoregulation

**Main_simulations_functions_1**

Contains functions which calculate the LCI for one set of primary parameters and the functions which iterate this calculation to propagate uncertainty and assess sensitivity.  


<br>
*The scripts named with a 2 can be used to observe the behaviour of some of the model's modules.*  
<br>






**Thermoregulation_Validation_Perez_Lopez_2**  

Validates the thermoregulation module by simulating thermoregulation in the same conditions as the PBR operated in Pérez-López et al. 2017. 


**Thermoregulation_behaviour_2**  

Simulates the temperature evolution and thermoregulation and plots results for different primary parameters.


**Fish_feed_Optimization_behaviour_2**  

Demonstrates the behaviour of the optimization algorithm for fish feed substitution.

**Geometry_and_solar_power_behaviour_2**  

Demonstrates the behaviour of the module estimating the solar power received by a given PBR geometry.


<br>

*Scripts without numbers in their names are to be executed to obtain the figures from the article.*  

<br>

## Reproducing results from the article


*You need :*

-Miniconda or Anaconda
https://docs.conda.io/projects/conda/en/latest/user-guide/install/index.html

-A local version of Ecoinvent 3.6 consequential

-A python interface ( for ex. Spyder) a R interface(for ex. Rstudio)


1. **Download the files (ZIP repository) and extract the files to a folder   somewhere in your computer.**


2. **Install the conda environment with all needed packages from the yml file and activate it.**

+ Open your command prompt or Anaconda/Miniconda terminal.
+ Go to the "Code"" Folder in your architecture by typing :

```
 cd yourpathtoCode
```
+ Then create the conda environment with all necessary packages using the yml.file

```
conda env create --file environment_microalgae.yml
```

+ If you experience issues, try with the txt file :

```
conda env create --file text_environment_microalgae.txt
```

+ Now, still in the "Code" folder, activate the newly created environment with :

```
conda activate environment_microalgae
```



3. **Launch spyder and set up the Brigtway2 project**



+ Open spyder from the Miniconda/Anaconda terminal or command prompt by typing

```
spyder
```

+ You should see, with your own path to 'Code' :

<img src="conda window 2.jpg"
     alt="Markdown Monster icon"
     style="float: left; margin-right: 10px;" />


+ In spyder, make sure the working directory is 'Code' or change it accordingly.

+ From spyder, open the script **_Load_project_**
Execute the whole script to load the Brightway2 project.

+ Import Ecoinvent 3.6 Consequential in this project. If needed, you can use the script **_Ecoinvent_3.6_conseq_import_**


4. **Run the simulations** 

+ Open the script **_Simulate_**
Read the instructions at the top of the file and, as indicated, choose the size of the sample for the Fourier Amplitude Sensitivity test.
A value of 1200 (1200*6 parameters = 7200 combinations and iterations)was used in the article but a lower value can be chosen for lower calculation time.


<img src="spyder 1.png"
     alt="Markdown Monster icon"
     style="float: left; margin-right: 10px;" />
     
+ Wait for all the simulations to be finished. (Takes a few minutes to a few hours depending on the sample size and your computer)  
The script will export excel files in the folder 'Code'.


5. **Plot the figures based on the excel files generated**

+ Open the R script **_Plot_**. Set the working directory to 'Code'. 
+ Execute the whole script to plot the 3 original figures from the article  and export the jpeg files in the 'Code' folder :
+ **Figure_uncertainty.jpeg**
+ **Figure_sensitivity.jpeg**
+ **Figure_contributions.jpeg**  

You may have to install a few extra packages from CRAN as indicated by the R interface.

<br>  








Geider, Richard, and Julie La Roche. 2011. Redfield Revisited : Variability of C : N : P in Marine Microalgae and Its Biochemical Basis Redfield Revisited : Variability of C : N : P in Marine Microalgae and Its Biochemical Basis.
